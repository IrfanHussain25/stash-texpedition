let mediaRecorder;
let audioChunks = []; 
let headerChunk = null;

chrome.runtime.onMessage.addListener(async (message) => {
  
  if (message.action === "START_RECORDING") {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          mandatory: {
            chromeMediaSource: "tab",
            chromeMediaSourceId: message.streamId
          }
        }
      });

      const outputAudio = new Audio();
      outputAudio.srcObject = stream;
      outputAudio.play();

      mediaRecorder = new MediaRecorder(stream);
      
      mediaRecorder.ondataavailable = event => {
        if (!headerChunk && event.data.size > 0) {
          headerChunk = event.data;
          return;
        }

        audioChunks.push(event.data);
        if (audioChunks.length > 15) {
          audioChunks.shift(); 
        }
      };

      mediaRecorder.start(1000); 
      console.log("Ghost document attached. Header secured. Buffering...");

    } catch (err) {
      console.error("Ghost document failed to get audio:", err);
    }
  }

  if (message.action === "FLUSH_BUFFER") {
    console.log("Flushing old audio. Keeping the WebM header safe.");
    
    audioChunks = []; 
    
  }

  if (message.action === "CLIP_AUDIO") {
    if (audioChunks.length === 0 || !headerChunk) {
      console.error("Not enough audio buffered yet!");
      return;
    }

    console.log("Packaging last 15 seconds with the WebM header...");

    const audioBlob = new Blob([headerChunk, ...audioChunks], { type: 'audio/webm' });
    const reader = new FileReader();
    
    reader.onloadend = () => {
      const base64Audio = reader.result.split(',')[1];
      
      chrome.runtime.sendMessage({ 
        action: "AUDIO_CLIPPED", 
        base64Audio: base64Audio 
      });
    };
    
    reader.readAsDataURL(audioBlob); 
  }
});