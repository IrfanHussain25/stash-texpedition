let isPlaying = false;

document.addEventListener('play', (e) => {
  if (e.target && e.target.tagName === 'VIDEO') {
    if (!isPlaying) {
      isPlaying = true;
      console.log("Stash: YouTube video started playing.");
      chrome.runtime.sendMessage({ action: "YOUTUBE_PLAYING" });
    }
  }
}, true);

document.addEventListener('pause', (e) => {
  if (e.target && e.target.tagName === 'VIDEO') {
    isPlaying = false;
  }
}, true);
