// let capturingTabId = null;

// chrome.action.onClicked.addListener(async (tab) => {
//   if (capturingTabId !== null) {
//     await stopCapture();
//   } else {
//     startCaptureForTab(tab.id);
//   }
// });

// async function stopCapture() {
//   if (capturingTabId === null) return;
  
//   // Explicitly flush any old audio before closing
//   chrome.runtime.sendMessage({ action: "FLUSH_BUFFER" }).catch(() => {});
  
//   capturingTabId = null;
  
//   const existingContexts = await chrome.runtime.getContexts({
//     contextTypes: ['OFFSCREEN_DOCUMENT'],
//   });
//   if (existingContexts.length > 0) {
//     await chrome.offscreen.closeDocument();
//   }
  
//   chrome.notifications.create({
//     type: "basic",
//     iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
//     title: "Stash Stopped",
//     message: "The hidden audio wire has been disconnected."
//   });
// }

// async function startCaptureForTab(tabId) {
//   if (capturingTabId === tabId) {
//     console.log("Already capturing this tab.");
//     return;
//   }

//   await setupOffscreenDocument();
  
//   chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
//     if (chrome.runtime.lastError) {
//       console.error("Tab Capture Error:", chrome.runtime.lastError.message);
//       return;
//     }

//     capturingTabId = tabId;

//     chrome.runtime.sendMessage({ action: "START_RECORDING", streamId: streamId });
    
//     chrome.notifications.create({
//       type: "basic",
//       iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
//       title: "Stash is Listening",
//       message: "The hidden audio wire is connected!"
//     });
//   });
// }

// chrome.commands.onCommand.addListener((command) => {
//   if (command === "clip-stash") {
//     console.log("Hotkey pressed! Telling ghost document to clip...");
//     chrome.runtime.sendMessage({ action: "CLIP_AUDIO" });
//   }
// });

// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   if (message.action === "AUDIO_CLIPPED") {
//     sendToRealAI(message.base64Audio);
//   }
// });

// async function sendToRealAI(base64Audio) {
//   chrome.notifications.create({
//     type: "basic",
//     iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
//     title: "Stash Analyzing...",
//     message: "Sending audio to Gemini via Python backend..."
//   });

//   try {
//     const response = await fetch("http://127.0.0.1:8000/api/audio", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ 
//         audio_b64: base64Audio,
//         mime_type: "audio/webm"
//       })
//     });

//     const data = await response.json();
//     console.log("Received from Python Backend:", data);

//     chrome.notifications.create({
//       type: "basic",
//       iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
//       title: "Item Stashed!",
//       message: `${data.product_name || "Unknown Product"} - ${data.price || "Unknown Price"}`
//     });

//   } catch (error) {
//     console.error("Backend connection failed:", error);
//     chrome.notifications.create({
//       type: "basic",
//       iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
//       title: "Server Error",
//       message: "Is Person B's FastAPI server running?"
//     });
//   }
// }

// async function setupOffscreenDocument() {
//   const existingContexts = await chrome.runtime.getContexts({
//     contextTypes: ['OFFSCREEN_DOCUMENT'],
//   });
//   if (existingContexts.length > 0) return;

//   await chrome.offscreen.createDocument({
//     url: 'offscreen.html',
//     reasons: ['USER_MEDIA'],
//     justification: 'Recording audio for Stash background capture',
//   });
// }



// chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
//   if (capturingTabId === tabId && changeInfo.url) {
//     if (changeInfo.url.includes("youtube.com/watch")) {
//       console.log("YouTube SPA navigation detected! Auto-flushing buffer.");
      
//       chrome.runtime.sendMessage({ action: "FLUSH_BUFFER" });
      
//       chrome.notifications.create({
//         type: "basic",
//         iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
//         title: "Stash Auto-Tracking",
//         message: "Listening to the new video automatically!"
//       });
//     } else {
//       console.log("Navigated away from YouTube video. Stopping capture.");
//       stopCapture();
//     }
//   }
// });

// chrome.tabs.onRemoved.addListener((tabId) => {
//   if (capturingTabId === tabId) {
//     console.log("Captured tab was closed. Stopping capture.");
//     stopCapture();
//   }
// });









let capturingTabId = null;
let latestScreenshotBase64 = null;

// --- STEP 1: INITIALIZE TAB CAPTURE VIA ICON CLICK ---
chrome.action.onClicked.addListener((tab) => {
  if (capturingTabId) {
    stopCapture();
  } else {
    startCaptureForTab(tab.id);
  }
});

async function stopCapture() {
  if (!capturingTabId) return;
  console.log("Stopping capture...");
  capturingTabId = null;
  
  chrome.action.setBadgeText({ text: "" });
  
  try {
    await chrome.offscreen.closeDocument();
    console.log("Offscreen document closed, recording stopped.");
  } catch (err) {
    console.log("No offscreen document to close.");
  }
}

async function startCaptureForTab(tabId) {
  if (capturingTabId === tabId) {
    console.log("Already capturing this tab.");
    return;
  }

  await setupOffscreenDocument();
  
  chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
    if (chrome.runtime.lastError) {
      console.error("Tab Capture Error:", chrome.runtime.lastError.message);
      return;
    }

    capturingTabId = tabId;

    chrome.runtime.sendMessage({ action: "START_RECORDING", streamId: streamId });
    
    chrome.action.setBadgeText({ text: "REC" });
    chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
    
    chrome.notifications.create({
      type: "basic",
      iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
      title: "Stash is Listening",
      message: "The hidden audio wire is connected!"
    });
  });
}

// --- STEP 2: MULTIMODAL HOTKEY EXECUTION ---
chrome.commands.onCommand.addListener((command) => {
  if (command === "clip-stash") {
    console.log("Hotkey pressed! Capturing active viewport screenshot...");

    // Capture the current visible viewport as a highly compressed JPEG
    chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 80 }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        console.error("Screenshot capture failed:", chrome.runtime.lastError.message);
        latestScreenshotBase64 = null; 
      } else {
        // Strip out the data URL schema prefix
        latestScreenshotBase64 = dataUrl.split(',')[1];
        console.log(`📸 Screenshot captured successfully! Size: ${latestScreenshotBase64.length} chars`);
      }

      console.log("Screenshot secured. Pulling rolling audio loop data...");
      chrome.action.setBadgeText({ text: "..." });
      chrome.action.setBadgeBackgroundColor({ color: "#FFA500" });
      chrome.runtime.sendMessage({ action: "CLIP_AUDIO" });

      chrome.notifications.create({
        type: "basic",
        iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
        title: "Stash Analyzing...",
        message: "Capturing current screen view and audio context..."
      });
    });
  }
});

// --- STEP 3: DATA COORDINATION & BACKEND DISPATCH ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "AUDIO_CLIPPED") {
    // Both context assets are ready; dispatching to our endpoint
    sendToRealAI(message.base64Audio, latestScreenshotBase64);
    latestScreenshotBase64 = null; // Clean out memory allocation immediately
  }
});

async function sendToRealAI(base64Audio, base64Image) {
  console.log(`🚀 Dispatching payload to backend! Audio Length: ${base64Audio?.length || 0}, Image Length: ${base64Image?.length || "None"}`);
  try {
    const response = await fetch("http://127.0.0.1:8000/api/video", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ 
        audio_b64: base64Audio,
        image_b64: base64Image,
        mime_type: "audio/webm"
      })
    });

    const data = await response.json();
    console.log("Received from Python Backend:", data);

    const product = data.extracted?.product_name || "Unknown Product";
    const price = data.extracted?.price ? `$${data.extracted.price}` : "Unknown Price";

    chrome.action.setBadgeText({ text: "✔" });
    chrome.action.setBadgeBackgroundColor({ color: "#00FF00" });
    setTimeout(() => {
      chrome.action.setBadgeText({ text: "REC" });
      chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
    }, 4000);

    chrome.notifications.create({
      type: "basic",
      iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
      title: "Item Stashed!",
      message: `${product} - ${price}`
    });

  } catch (error) {
    console.error("Backend connection failed:", error);
    chrome.action.setBadgeText({ text: "ERR" });
    chrome.action.setBadgeBackgroundColor({ color: "#000000" });
    setTimeout(() => {
      chrome.action.setBadgeText({ text: "REC" });
      chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
    }, 4000);
    chrome.notifications.create({
      type: "basic",
      iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",
      title: "Server Error",
      message: "Is your FastAPI backend server active?"
    });
  }
}

// --- STEP 4: OFFSCREEN MANAGEMENT ---
async function setupOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  if (existingContexts.length > 0) return;

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Recording audio loops for background web analysis',
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (capturingTabId === tabId && changeInfo.url) {
    if (changeInfo.url.includes("youtube.com/watch") || changeInfo.url.includes("youtube.com/shorts") || changeInfo.url.includes("instagram.com/reel/")) {
      console.log("Dynamic tab routing event logged! Flushing outdated sound buffer.");
      
      chrome.runtime.sendMessage({ action: "FLUSH_BUFFER" }).catch(() => {});
      
      chrome.notifications.create({
        type: "basic",
        iconUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=", 
        title: "Stash Auto-Tracking",
        message: "Audio buffer reset for your new video context!"
      });
    }
  }
});